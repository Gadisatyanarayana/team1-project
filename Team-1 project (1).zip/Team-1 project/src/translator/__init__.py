"""
Translator package initialization
"""

from .engine import TranslationEngine
from .dictionary import Dictionary
from .processor import TextProcessor

__all__ = ['TranslationEngine', 'Dictionary', 'TextProcessor']
