"""
Translation engine for Hindi to Santali translation
"""

from typing import Dict, Optional
from .dictionary import Dictionary
from .processor import TextProcessor
import json

# Hindi to Ol Chiki letter mapping for fallback transliteration
HINDI_OLCHIKI_MAP = {
    'अ': 'ᱚ', 'आ': 'ᱟ', 'इ': 'ᱤ', 'ई': 'ᱤ', 'उ': 'ᱩ', 'ऊ': 'ᱩ',
    'ए': 'ᱮ', 'ऐ': 'ᱮ', 'ओ': 'ᱳ', 'औ': 'ᱳ', 'ऋ': 'ᱨᱤ',
    'क': 'ᱠ', 'ख': 'ᱠ', 'ग': 'ᱜ', 'घ': 'ᱜ', 'ङ': 'ᱝ',
    'च': 'ᱪ', 'छ': 'ᱪ', 'ज': 'ᱡ', 'झ': 'ᱡ', 'ञ': 'ᱧ',
    'ट': 'ᱴ', 'ठ': 'ᱴ', 'ड': 'ᱫ', 'ढ': 'ᱫ', 'ण': 'ᱱ',
    'त': 'ᱛ', 'थ': 'ᱛ', 'द': 'ᱰ', 'ध': 'ᱰ', 'न': 'ᱱ',
    'प': 'ᱯ', 'फ': 'ᱯ', 'ब': 'ᱵ', 'भ': 'ᱵ', 'म': 'ᱢ',
    'य': 'ᱭ', 'र': 'ᱨ', 'ल': 'ᱞ', 'व': 'ᱣ',
    'श': 'ᱥ', 'ष': 'ᱥ', 'स': 'ᱥ', 'ह': 'ᱦ',
    'ळ': 'ᱞ', 'क्ष': 'ᱠᱥ', 'ज्ञ': 'ᱡᱱ',
    '०': '᱐', '१': '᱑', '२': '᱒', '३': '᱓', '४': '᱔', '५': '᱕', '६': '᱖', '७': '᱗', '८': '᱘', '९': '᱙',
    'ा': 'ᱟ', 'ि': 'ᱤ', 'ी': 'ᱤ', 'ु': 'ᱩ', 'ू': 'ᱩ', 'े': 'ᱮ', 'ै': 'ᱮ', 'ो': 'ᱳ', 'ौ': 'ᱳ', 'ृ': 'ᱨᱤ',
    'ं': 'ᱝ', 'ः': 'ᱦ', 'ँ': 'ᱝ', '्': '',
}

class TranslationEngine:
    """Main translation engine"""
    
    def __init__(self, dictionary_path=None):
        """Initialize translation engine
        
        Args:
            dictionary_path: Path to dictionary file (defaults to hindi_santali_final.csv)
        """
        # Use the actual dataset file in the project root
        # Priority: final (consolidated 3385+ entries) > master_v2 > master > enhanced > original
        if dictionary_path is None:
            import os
            project_root = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
            
            # Try final consolidated dataset first
            final_dataset = os.path.join(project_root, 'hindi_santali_final.csv')
            if os.path.exists(final_dataset):
                dictionary_path = final_dataset
            # Try master v2 dataset
            elif os.path.exists(os.path.join(project_root, 'hindi_santali_master_v2.csv')):
                dictionary_path = os.path.join(project_root, 'hindi_santali_master_v2.csv')
            # Try master v1 dataset
            elif os.path.exists(os.path.join(project_root, 'hindi_santali_master.csv')):
                dictionary_path = os.path.join(project_root, 'hindi_santali_master.csv')
            # Try enhanced dataset
            elif os.path.exists(os.path.join(project_root, 'hindi_santali_enhanced.csv')):
                dictionary_path = os.path.join(project_root, 'hindi_santali_enhanced.csv')
            # Try final merged dataset
            elif os.path.exists(os.path.join(project_root, 'hindi_santali_dataset_final.csv')):
                dictionary_path = os.path.join(project_root, 'hindi_santali_dataset_final.csv')
            # Fall back to original dataset
            else:
                dictionary_path = os.path.join(project_root, 'hindi_santali_dataset.csv')
        
        self.dictionary = Dictionary(dictionary_path)
        self.processor = TextProcessor()
        self.translation_cache = {}
        self.max_cache_size = 10000  # Limit cache to prevent memory issues
    
    def _transliterate_hindi_to_olchiki(self, hindi_text: str) -> str:
        """Transliterate Hindi text to Ol Chiki letter-by-letter
        
        Args:
            hindi_text: Hindi text to transliterate
            
        Returns:
            Ol Chiki text
        """
        result = []
        for char in hindi_text:
            if char in HINDI_OLCHIKI_MAP:
                result.append(HINDI_OLCHIKI_MAP[char])
            else:
                result.append(char)
        return ''.join(result)
    
    
    def translate(self, text: str, source_lang='hi', target_lang='sat') -> Dict:
        """Translate text from Hindi to Santali
        
        Args:
            text: Text to translate
            source_lang: Source language code
            target_lang: Target language code
            
        Returns:
            Dictionary with translation results
        """
        # Normalize language codes - strip whitespace and convert to lowercase
        source_lang = str(source_lang).strip().lower() if source_lang else 'hi'
        target_lang = str(target_lang).strip().lower() if target_lang else 'sat'
        
        if not text or not text.strip():
            return {
                'success': False,
                'error': 'Empty input text',
                'source_text': text,
                'translated_text': '',
                'confidence': 0.0
            }
        
        # Check cache (limit cache size)
        cache_key = source_lang + "_" + target_lang + "_" + text
        if cache_key in self.translation_cache:
            return self.translation_cache[cache_key]
        
        # Validate language pairs
        if not self._is_valid_language_pair(source_lang, target_lang):
            return {
                'success': False,
                'error': 'Unsupported language pair: {} -> {}'.format(source_lang, target_lang),
                'source_text': text,
                'translated_text': ''
            }
        
        # Process input
        cleaned_text = self.processor.preprocess(text)
                # Perform translation
        if source_lang == 'hi' and target_lang == 'sat':
            result = self._translate_hindi_to_santali(cleaned_text)
        elif source_lang == 'sat' and target_lang == 'hi':
            result = self._translate_santali_to_hindi(cleaned_text)
        else:
            result = {
                'success': False,
                'error': 'Translation not supported',
                'source_text': text,
                'translated_text': ''
            }
        
        # Cache result
        self.translation_cache[cache_key] = result
        
        return result
    
    def _translate_hindi_to_santali(self, hindi_text: str) -> Dict:
        """Translate Hindi text to Santali
        
        Args:
            hindi_text: Hindi text to translate
            
        Returns:
            Translation result dictionary
        """
        # First, try to match the entire text as a phrase
        full_phrase_match = self.dictionary.lookup_hindi_to_santali(hindi_text.strip())
        if full_phrase_match:
            return {
                'success': True,
                'source_text': hindi_text,
                'source_language': 'Hindi',
                'translated_text': full_phrase_match,
                'target_language': 'Santali',
                'confidence': 100.0,
                'method': 'exact_phrase_match',
                'word_mappings': [{
                    'hindi': hindi_text,
                    'santali': full_phrase_match,
                    'source': 'dictionary',
                    'confidence': 1.0
                }],
                'matched_words': 1,
                'total_words': 1
            }
        
        # If no full phrase match, proceed with sentence and word-by-word translation
        sentences = self.processor.tokenize_sentences(hindi_text)
        translated_sentences = []
        word_mappings = []
        total_confidence = 0.0
        matched_words = 0
        total_words = 0
        
        for sentence in sentences:
            words = self.processor.tokenize_words(sentence)
            translated_words = []
            
            for word in words:
                # Skip punctuation and special characters
                if not word or word in ['।', '॥', '.', ',', '!', '?', '-', ':', ';']:
                    translated_words.append(word)
                    continue
                
                # Try dictionary lookup (exact match first)
                translated_word = self.dictionary.lookup_hindi_to_santali(word)
                
                if translated_word:
                    translated_words.append(translated_word)
                    word_mappings.append({
                        'hindi': word,
                        'santali': translated_word,
                        'source': 'dictionary',
                        'confidence': 1.0
                    })
                    matched_words += 1
                    total_words += 1
                else:
                    # Try fuzzy match as fallback
                    fuzzy_result = self.dictionary.fuzzy_match_hindi_to_santali(word, threshold=0.65)
                    if fuzzy_result:
                        translated_word, confidence = fuzzy_result
                        translated_words.append(translated_word)
                        word_mappings.append({
                            'hindi': word,
                            'santali': translated_word,
                            'source': 'fuzzy_match',
                            'confidence': round(confidence, 2)
                        })
                        matched_words += 1
                        total_words += 1
                    else:
                        # Try partial match (word contains key)
                        partial_match = self._find_partial_match(word)
                        if partial_match:
                            translated_words.append(partial_match)
                            word_mappings.append({
                                'hindi': word,
                                'santali': partial_match,
                                'source': 'partial_match',
                                'confidence': 0.7
                            })
                            total_words += 1
                        else:
                            # Fallback: Transliterate Hindi to Ol Chiki letter-by-letter
                            transliterated = self._transliterate_hindi_to_olchiki(word)
                            translated_words.append(transliterated)
                            word_mappings.append({
                                'hindi': word,
                                'santali': transliterated,
                                'source': 'transliteration',
                                'confidence': 0.5
                            })
                            total_words += 1
            
            translated_sentence = ' '.join(translated_words)
            translated_sentences.append(translated_sentence)
        
        translated_text = ' '.join(translated_sentences)
        confidence = (matched_words / total_words * 100) if total_words > 0 else 0
        
        return {
            'success': True,
            'source_text': hindi_text,
            'source_language': 'Hindi',
            'translated_text': translated_text,
            'target_language': 'Santali',
            'confidence': round(confidence, 2),
            'word_mappings': word_mappings,
            'matched_words': matched_words,
            'total_words': total_words
        }
    
    def _translate_santali_to_hindi(self, santali_text: str) -> Dict:
        """Translate Santali text to Hindi
        
        Args:
            santali_text: Santali text to translate
            
        Returns:
            Translation result dictionary
        """
        sentences = self.processor.tokenize_sentences(santali_text)
        translated_sentences = []
        word_mappings = []
        total_confidence = 0.0
        matched_words = 0
        total_words = 0
        
        for sentence in sentences:
            words = self.processor.tokenize_words(sentence)
            translated_words = []
            
            for word in words:
                # Skip punctuation and special characters
                if not word or word in ['।', '॥', '.', ',', '!', '?', '-', ':', ';']:
                    translated_words.append(word)
                    continue
                
                # Try dictionary lookup
                translated_word = self.dictionary.lookup_santali_to_hindi(word)
                
                if translated_word:
                    translated_words.append(translated_word)
                    word_mappings.append({
                        'santali': word,
                        'hindi': translated_word,
                        'source': 'dictionary',
                        'confidence': 1.0
                    })
                    matched_words += 1
                    total_words += 1
                else:
                    # Try fuzzy match as fallback
                    fuzzy_result = self.dictionary.fuzzy_match_santali_to_hindi(word, threshold=0.65)
                    if fuzzy_result:
                        translated_word, confidence = fuzzy_result
                        translated_words.append(translated_word)
                        word_mappings.append({
                            'santali': word,
                            'hindi': translated_word,
                            'source': 'fuzzy_match',
                            'confidence': round(confidence, 2)
                        })
                        matched_words += 1
                        total_words += 1
                    else:
                        # Keep original word if not found
                        translated_words.append(word)
                        word_mappings.append({
                            'santali': word,
                            'hindi': word,
                            'source': 'unknown',
                            'confidence': 0.0
                        })
                        total_words += 1
            
            translated_sentence = ' '.join(translated_words)
            translated_sentences.append(translated_sentence)
        
        translated_text = ' '.join(translated_sentences)
        confidence = (matched_words / total_words * 100) if total_words > 0 else 0
        
        return {
            'success': True,
            'source_text': santali_text,
            'source_language': 'Santali',
            'translated_text': translated_text,
            'target_language': 'Hindi',
            'confidence': round(confidence, 2),
            'word_mappings': word_mappings,
            'matched_words': matched_words,
            'total_words': total_words
        }
    
    def _is_valid_language_pair(self, source_lang, target_lang) -> bool:
        """Validate language pair
        
        Args:
            source_lang: Source language code
            target_lang: Target language code
            
        Returns:
            True if valid language pair
        """
        valid_pairs = [
            ('hi', 'sat'),  # Hindi to Santali
            ('sat', 'hi'),  # Santali to Hindi
        ]
        return (source_lang, target_lang) in valid_pairs
    
    def _find_partial_match(self, word: str) -> Optional[str]:
        """Find partial match for a word in dictionary
        
        Args:
            word: Word to find partial match for
            
        Returns:
            Translated word or None
        """
        word_lower = word.lower()
        all_words = self.dictionary.get_all_words()
        
        # Check if word is substring of any key
        for hindi_word, santali_word in all_words.items():
            if word_lower == hindi_word.lower()[:len(word_lower)] or \
               hindi_word.lower() == word_lower[:len(hindi_word)]:
                return santali_word
        
        return None
    
    def batch_translate(self, texts: list, source_lang='hi', target_lang='sat') -> list:
        """Translate multiple texts
        
        Args:
            texts: List of texts to translate
            source_lang: Source language code
            target_lang: Target language code
            
        Returns:
            List of translation results
        """
        results = []
        for text in texts:
            result = self.translate(text, source_lang, target_lang)
            results.append(result)
        return results
    
    def get_supported_languages(self) -> Dict[str, str]:
        """Get supported languages
        
        Returns:
            Dictionary of language codes and names
        """
        return {
            'hi': 'Hindi',
            'sat': 'Santali'
        }
    
    def clear_cache(self):
        """Clear translation cache"""
        self.translation_cache.clear()
