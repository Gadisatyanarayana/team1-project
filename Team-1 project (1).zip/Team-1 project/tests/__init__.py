"""
Tests initialization
"""
